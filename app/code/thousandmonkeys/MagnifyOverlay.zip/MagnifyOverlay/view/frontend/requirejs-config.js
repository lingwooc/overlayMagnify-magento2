var config = {
    "paths": {
        "magnifier/magnify": "thousandmonkeys_OverlayMagnify/js/magnify",
    },
    'config': {
        'mixins': {
            'mage/gallery/gallery': {
                "thousandmonkeys_OverlayMagnify/js/galleryMixin": true
            }
        }
    }
};